package com.postgres.sample.dto;

import java.util.List;

import lombok.Data;

@Data
public class LjhResponse {
	List<?>		list;
	List<?>		secList;
	Object		obj;
}
