package com.postgres.sample.dto;

import lombok.Data;

@Data
public class CategoryVO {

	private String tbl_name;
	private String field_name;
	
}
