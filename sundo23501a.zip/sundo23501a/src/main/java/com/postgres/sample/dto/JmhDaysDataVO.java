package com.postgres.sample.dto;

import java.util.List;

import lombok.Data;

@Data
public class JmhDaysDataVO {	
	private String day;
	private String count;
}
