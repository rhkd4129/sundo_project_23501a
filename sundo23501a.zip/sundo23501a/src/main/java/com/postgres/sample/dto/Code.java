package com.postgres.sample.dto;

import lombok.Data;

@Data
public class Code {
	private String field_name;
	private String cate_code;
	private String field_title;
	private String cate_name;
}
