package com.postgres.sample.dto;

import lombok.Data;

@Data
public class CheckItemInfo {
	private String check_category;
	private String check_item;
}
