package com.postgres.sample.dto;

import lombok.Data;

@Data
public class OrgArea {
	private String org_area;
	private String org_area_name;
}
