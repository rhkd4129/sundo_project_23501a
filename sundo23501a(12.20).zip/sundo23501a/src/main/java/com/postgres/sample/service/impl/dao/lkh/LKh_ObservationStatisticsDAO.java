package com.postgres.sample.service.impl.dao.lkh;


import org.egovframe.rte.psl.dataaccess.mapper.Mapper;

@Mapper("observationStatisticsDAO")
public interface LKh_ObservationStatisticsDAO {
}
